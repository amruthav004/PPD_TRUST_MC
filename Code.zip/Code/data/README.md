# Data inputs

Place `PPD_dataset_v2.csv` here. The external file is optional and must be named
`LTM III national.tab` under the default configuration. Change the JSON path if
using the alternative spelling `LTM_III_national.tab`.

The upload contains notebook code and saved outputs, not the raw datasets.
Obtain the source files and their codebooks through the study's data-access
arrangements. No dataset download address or redistribution license is recorded
in the notebook. No generated participant records are included.

See `metadata/dataset_schema.json` and `metadata/data_dictionary.json` for
endpoint rules, leakage exclusions and explicitly named fields.
